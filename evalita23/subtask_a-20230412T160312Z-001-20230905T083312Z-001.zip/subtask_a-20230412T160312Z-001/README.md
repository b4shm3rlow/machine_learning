====================================================================================================
GeoLingIt: Geolocation of Linguistic Variation in Italy. A shared task at EVALITA 2023
----------------------------------------------------------------------------------------------------
This file provides information about GeoLingIt. Additional information and updates can be found at:
- [1] Website: https://sites.google.com/view/geolingit
- [2] Github repository: https://github.com/dhfbk/geolingit-evalita2023
====================================================================================================


================
Folder structure
================

This folder contains two subfolders, one for each subtask, each with training and development sets.

- subtask_a/: this folder contains data for subtask A
	- train_a.tsv: the training set
	- dev_a.tsv: the development set

- subtask_b/: this folder contains data for subtask B
	- train_b.tsv: the training set
	- dev_b.tsv: the development set


========================================
Information about splits and evalutation
========================================

The data consists of training and development splits for both the subtasks. Test data will be provided on May 7th.

- Training set: it contains 13,669 tweets covering all the administrative regions of Italy. Participants are allowed to use additional (or new) material for training; however, the only external source that they can not use is Twitter, since some tweets can be part of our test set

- Development set: it contains 552 tweets from 13 selected regions (i.e., calabria, campania, friuli venezia-giulia, emilia-romagna, lazio, liguria, lombardia, piemonte, puglia, sardegna, sicilia, toscana, veneto). Participants are encouraged to use this set to compare the performance of their solutions against the baselines

- Test set: it contains tweets covering the aforementioned regions ("known" during development) plus 1<=k<=7 regions ("unknown" during development). This is to encourage generic solutions (i.e., for all Italy) that can effectively model language variation across space

The evaluation scorer is available on the GeoLingIt Github repository [2].


===========
Data format
===========

The dataset is in a tab-separated format, with an example per line and the first line as header. Depending on the subtask, the column(s) with answers differ as follows.

---------
Subtask A
---------

Each example has three columns:
- id: the tweet identifier, that we programmatically change to preserve user's anonymity
- text: the text of the tweet, with masked user mentions, email addresses, URLs, and locations from cross-posting
- region: the region of Italy in a string format

Note: the format of prediction files for this subtask must follow this exact format to be properly evaluated.

---------
Subtask B
---------

Each example has four columns:
- id: the tweet identifier, that we programmatically change to preserve user's anonymity
- text: the text of the tweet, with masked user mentions, email addresses, URLs, and locations from cross-posting
- latitude: a float representing the latitude coordinate of the tweet
- longitude: a float representing the longitude coordinate of the tweet

Note: the format of prediction files for this subtask must follow this exact format to be properly evaluated.


========
Curation
========

The dataset is the result of several weeks of manual work and dedication. We made our best effort to limit as much as possible the content created by relocated users or tourists in places where their variety is not spoken for certain (e.g., Neapolitan in Sardinia during the summer), to make the dataset as representative as possible of language variation in Italy. However, we kept a fraction of those tweets on purpose in the training set, in order to allow participants to use (or not) this information. Development data underwent an additional curation phase: those tweets have been discarded and we made our best effort to further represent micro-variation.


========================
Density and distribution
========================

The density and representation of linguistic phenomena (e.g., entire posts in a variety, code-switching, single lexical items, etc.) vary from region to region, and indeed the less "dense" ones reflect the language replacement we are observing nowadays. Regions in which indigenous varieties or dialects are frequently spoken are more represented than regions where those are at risk of disappearing very soon. Each region typically contains multiple varieties, and intermediate varieties are common at borders. Regional Italian is also present, and some phrases are used in areas wider than a single administrative region, with different distribution among individual regions.


=============
Preprocessing
=============

The data has been anonymized by replacing user mentions, email addresses and URLs with placeholders (i.e., [USER], [EMAIL] and [URL], respectively). Additionally, explicit location mentions derived from cross-posting have been replaced with the [LOCATION] placeholder. No additional preprocessing has been conducted.

Notes about data loading: when loading the dataset with python libraries (e.g., pandas) or excel, the parsing may be prone to errors. We dediced to preserve the original text (with placeholders) in our dataset instead of preparing the dataset for specific libraries (e.g., escaping some characters). Please ensure the number of loaded rows matches the number of instances in the dataset when using those libraries.


==================
Duplicate handling
==================

We removed all duplicates written by the same user from the data during the curation process. However, the text of some posts might be repeated with different annotations within the dataset. This could happen when two different users posted the same message from different locations. These examples are preserved as the different geolocation of a similar message can be useful, and the participant can decide to filter this implicit information or not.


=========
Baselines
=========

The scores for the baselines are available on the GitHub repository [2]. Additional baselines will be provided during the competition.


=============================
Potentially offensive content
=============================

Since the dataset consists of social media posts, it contains some profanities, slurs, and hateful content.


==============================
Ethical and license statements
==============================

The dataset is meant to study how language use varies across space. As such, information about individual users is not distributed nor can be used by participants. Additionally, user mentions, email addresses and URLs within the text of posts have been anonymized with placeholders. Latitude and longitude coordinates do not correspond to specific places within cities, but instead represent cities as a whole (i.e., posts within the same city will have the same coordinates). Results are meant to be only used in an aggregate form to study diatopic linguistic variation. The data is licensed under the CC BY-NC-SA 4.0 license (https://creativecommons.org/licenses/by-nc-sa/4.0/legalcode) and complies with the Twitter developer policy. The dataset can only be used for research purposes.